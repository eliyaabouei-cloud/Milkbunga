import Foundation

extension ProcessInfo {
    public static var osVersion: String {
        get {
            return "\(ProcessInfo.processInfo.operatingSystemVersion.majorVersion).\(ProcessInfo.processInfo.operatingSystemVersion.minorVersion).\(ProcessInfo.processInfo.operatingSystemVersion.patchVersion)"
        }
    }
}
