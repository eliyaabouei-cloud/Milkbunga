import SwiftUI

struct LinkCell: View {
    var imageName: String
    var url: String? = nil
    var title: String
    var contribution: String
    var systemImage: Bool = false
    var circle: Bool = true
    @Environment(\.openURL) var openURL
    
    var body: some View {
        NiceButton(text: AnyView(
            HStack(alignment: .center) {
                Group {
                    if systemImage {
                        Image(systemName: imageName)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                    } else {
                        if imageName != "" {
                            Image(imageName)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                        }
                    }
                }
                .cornerRadius(circle ? .infinity : 0)
                .frame(width: 24, height: 24)
                Text(title).fontWeight(.bold)
                Text(contribution).foregroundColor(.secondary)
            }.padding(0)
        ), action: {
            if let url = url {
                openURL(URL(string: url)!)
            }
        })
    }
}

struct HomeView: View {
    
    @StateObject private var dataSingleton = DataSingleton.shared
    @Environment(\.openURL) var openURL
    
    var body: some View {
        VStack {
            List {
                // --- بخش اطلاعات دستگاه متصل ---
                Group {
                    HStack {
                        if dataSingleton.currentDevice?.name != nil {
                            Image(systemName: dataSingleton.currentDevice?.ipad == true ? "ipad" : "iphone")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 35, height: 35)
                        } else {
                            Image(systemName: "iphone.slash")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 35, height: 35)
                        }
                        ZStack {
                            VStack {
                                HStack {
                                    Text(dataSingleton.currentDevice?.name ?? "No Device")
                                        .bold()
                                    Spacer()
                                }
                                HStack {
                                    Text(dataSingleton.currentDevice?.version ?? "Please connect a device.")
                                    if (dataSingleton.currentDevice?.uuid != nil) {
                                        if (!DataSingleton.shared.deviceAvailable) {
                                            Text("Not Supported.")
                                                .foregroundColor(.red)
                                        } else {
                                            if (!DataSingleton.shared.deviceTested) {
                                                Text("Supported, YMMV.")
                                                    .foregroundColor(.yellow)
                                            } else {
                                                Text("Supported!")
                                                    .foregroundColor(.green)
                                            }
                                        }
                                    }
                                    Spacer()
                                }
                            }
                        }
                    }
                    .hideSeparator()
                    
                    Divider()
                        .hideSeparator()
                }
                
                // --- بخش لوگو و اسم برنامه ---
                Group {
                    HStack {
                        Spacer()
                        
                        // 🍎 عکس لوگو اینجا قرار میگیره. باید توی Assets به اسم MilkbungaIcon باشه
                        Image("MilkbungaIcon")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(maxHeight: 150)
                            .padding(.horizontal, 20)
                            .padding(.vertical, 10)
                        
                        VStack {
                            // اسم برنامه
                            HStack {
                                Text("Milkbunga")
                                    .bold()
                                    .font(.largeTitle)
                                    .padding(.trailing, 10)
                                Spacer()
                            }
                        }
                        .frame(width: 250)
                        
                        Spacer()
                    }
                }
                .hideSeparator()
                
                // --- بخش سازنده (S8Hype) ---
                Group {
                    HStack {
                        // 🍎 عکس پروفایل S8Hype اینجا قرار میگیره. باید توی Assets به اسم S8HypeProfile باشه
                        Image("S8HypeProfile")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 40, height: 40)
                            .clipShape(Circle()) // دایره‌ای کردن عکس
                            .padding(.trailing, 10)
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text("S8Hype")
                                .fontWeight(.bold)
                            Text("Main Developer")
                                .foregroundColor(.secondary)
                        }
                        Spacer()
                    }
                    .padding(.vertical, 10)
                }
                .hideSeparator()
            }
            
            // --- بخش نسخه برنامه (پایین صفحه) ---
            HStack {
                Spacer()
                Text("Version 1.0")
                    .padding(.bottom, 10)
                    .padding(.trailing, 10)
                    .foregroundColor(.gray)
            }
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
