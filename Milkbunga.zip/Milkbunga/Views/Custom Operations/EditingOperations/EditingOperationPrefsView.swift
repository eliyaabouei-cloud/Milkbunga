import Foundation
import SwiftUI

struct EditingOperationPrefsView: View {
    @State var operation: AdvancedObject
    @State var Prefs: [AdvancedOperationPref] = []
    
    var body: some View {
        VStack {
            
        }
    }
}
