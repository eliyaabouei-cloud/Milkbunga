#pragma once
#import "StatusSetter.h"
@protocol StatusSetter;

@interface StatusSetter15 : NSObject <StatusSetter>

@end
