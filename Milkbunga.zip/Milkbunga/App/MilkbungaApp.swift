import SwiftUI

@main
struct CowabungaLiteApp: App {
    init() {
        if !fm.fileExists(atPath: documentsDirectory.path) {
            do {
                try fm.createDirectory(at: documentsDirectory, withIntermediateDirectories: false)
            } catch {
                Logger.shared.logMe("Error creating directory com.leemin.CowabungaLite")
            }
        }
        let _ = CCManager.getPresetsFolder()
    }
    
    var body: some Scene {
        WindowGroup {
            RootView()
                .onOpenURL(perform: { url in
                    // MARK: Opening .cowperation
                    if url.pathExtension.lowercased() == "cowperation" {
                        do {
                            try CustomOperationsManager.shared.importOperation(url)
                            
                            // update operations
                            CustomOperationsManager.shared.getOperations()
                        } catch {
                            Logger.shared.logMe(error.localizedDescription)
                        }
                    }
                })
                .handlesExternalEvents(preferring: Set(arrayLiteral: "*"), allowing: Set(arrayLiteral: "*"))
        }
        .commands {
            CommandGroup(replacing: CommandGroupPlacement.newItem) {
                EmptyView()
            }
        }
    }
}
